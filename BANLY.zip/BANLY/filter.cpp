#include "filter.h"

filter::filter()
{

}

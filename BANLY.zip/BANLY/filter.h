#ifndef FILTER_H
#define FILTER_H


class filter
{
public:
    filter();
};

#endif // FILTER_H
